import type { Locale } from "@/i18n/config";

const content = {
  bg: {
    nav: {
      garage: "Дигитален гараж",
      services: "Услуги",
      about: "За GARALANE",
      action: "Към гаража",
    },
    hero: {
      eyebrow: "НОВО ПРОСТРАНСТВО ЗА ТВОЯ АВТОМОБИЛ",
      titleFirst: "Всичко за",
      titleSecond: "автомобила ти.",
      titleAccent: "На едно място.",
      description:
        "Организирай автомобилите си, проследявай разходите и сервизната история и откривай подходящите услуги. По-лесен начин да се грижиш за колата си.",
      primary: "Разгледай гаража",
      secondary: "Открий услугите",
      note: "Създаваме по-доброто място за автомобилите ти.",
      index: "01 / 03",
    },
    intro: {
      eyebrow: "ЕДНА ПЛАТФОРМА. ПОВЕЧЕ ЯСНОТА.",
      title: "Твоят автомобил",
      accent: "заслужава по-добра организация.",
      description:
        "От първото зареждане до следващото обслужване — важната информация остава подредена, достъпна и лесна за проследяване.",
    },
    garage: {
      eyebrow: "01 / ДИГИТАЛЕН ГАРАЖ",
      title: "Познат автомобил.",
      titleAccent: "Нов начин на управление.",
      description:
        "Виж как може да изглежда личното пространство за автомобила ти. Данните по-долу са примерни.",
      dashboardLabel: "ПРЕГЛЕД НА АВТОМОБИЛА",
      demo: "ИНТЕРАКТИВНА ДЕМОНСТРАЦИЯ",
      car: "BMW 320d Touring",
      carDetails: "2018 · Дизел · Автоматик",
      status: "Активен автомобил",
      distanceLabel: "ПРОБЕГ",
      mileage: "148 250 км",
      tabExpenses: "Разходи",
      tabHistory: "История",
      expensesTitle: "Разходи за периода",
      expensesTotal: "€ 1 248",
      expensesPeriod: "Последните 6 месеца",
      categories: [
        { name: "Гориво", amount: "€ 628", percent: 50.3 },
        { name: "Поддръжка", amount: "€ 440", percent: 35.3 },
        { name: "Други", amount: "€ 180", percent: 14.4 },
      ],
      history: [
        {
          title: "Смяна на масло и филтри",
          date: "12 октомври 2026",
          amount: "€ 185",
        },
        {
          title: "Смяна на предни накладки",
          date: "18 август 2026",
          amount: "€ 255",
        },
        {
          title: "Годишен технически преглед",
          date: "03 юли 2026",
          amount: "€ 45",
        },
      ],
      footnote: "Примерни данни за визуализация",
      vehicleNumber: "01 / 01",
    },
    benefits: {
      eyebrow: "ПО-МАЛКО ХАОС. ПОВЕЧЕ КОНТРОЛ.",
      title: "Създаден за",
      accent: "ежедневието ти.",
      items: [
        {
          number: "01",
          title: "Всичко е подредено",
          description:
            "Информацията за автомобилите ти е организирана в едно лично пространство.",
        },
        {
          number: "02",
          title: "Знаеш какво харчиш",
          description:
            "По-ясен поглед върху горивото, обслужването и останалите разходи.",
        },
        {
          number: "03",
          title: "Нищо важно не се губи",
          description:
            "Сервизна история и важни събития, които можеш лесно да преглеждаш.",
        },
      ],
    },
    services: {
      eyebrow: "02 / АВТОМОБИЛНИ УСЛУГИ",
      title: "Правилната услуга.",
      accent: "По-лесно откриване.",
      description:
        "GARALANE ще събира на едно място различни автомобилни услуги, за да намираш по-лесно това, от което имаш нужда.",
      items: [
        { number: "01", name: "Автосервизи", detail: "Ремонти и обслужване" },
        { number: "02", name: "Автомивки", detail: "Грижа и почистване" },
        { number: "03", name: "Детайлинг", detail: "Професионална грижа" },
        {
          number: "04",
          name: "Части и аксесоари",
          detail: "Всичко необходимо",
        },
      ],
      note: "Каталогът с услуги е в процес на разработка.",
    },
    closing: {
      eyebrow: "GARALANE",
      title: "Твоят автомобил.",
      accent: "Твоят начин.",
      action: "Обратно към началото",
    },
    footer: {
      tagline: "Your car. Your way.",
      copyright: "© 2026 GARALANE",
      note: "Създадено с внимание към детайла.",
    },
  },
  en: {
    nav: {
      garage: "Digital garage",
      services: "Services",
      about: "About GARALANE",
      action: "Explore garage",
    },
    hero: {
      eyebrow: "A NEW SPACE FOR YOUR CAR",
      titleFirst: "Everything for",
      titleSecond: "your car.",
      titleAccent: "In one place.",
      description:
        "Organize your vehicles, track expenses and service history, and discover the right automotive services. A simpler way to care for your car.",
      primary: "Explore the garage",
      secondary: "Discover services",
      note: "Building a better home for your vehicles.",
      index: "01 / 03",
    },
    intro: {
      eyebrow: "ONE PLATFORM. MORE CLARITY.",
      title: "Your car",
      accent: "deserves better organization.",
      description:
        "From the first fuel stop to the next service, the important details stay organized, accessible, and easy to track.",
    },
    garage: {
      eyebrow: "01 / DIGITAL GARAGE",
      title: "A familiar car.",
      titleAccent: "A better way to manage it.",
      description:
        "Take a look at what your personal vehicle space could look like. The information below is sample data.",
      dashboardLabel: "VEHICLE OVERVIEW",
      demo: "INTERACTIVE DEMO",
      car: "BMW 320d Touring",
      carDetails: "2018 · Diesel · Automatic",
      status: "Active vehicle",
      distanceLabel: "MILEAGE",
      mileage: "148,250 km",
      tabExpenses: "Expenses",
      tabHistory: "History",
      expensesTitle: "Expenses for the period",
      expensesTotal: "€ 1,248",
      expensesPeriod: "Last 6 months",
      categories: [
        { name: "Fuel", amount: "€ 628", percent: 50.3 },
        { name: "Maintenance", amount: "€ 440", percent: 35.3 },
        { name: "Other", amount: "€ 180", percent: 14.4 },
      ],
      history: [
        {
          title: "Engine oil and filter change",
          date: "12 October 2026",
          amount: "€ 185",
        },
        {
          title: "Front brake pad replacement",
          date: "18 August 2026",
          amount: "€ 255",
        },
        {
          title: "Annual vehicle inspection",
          date: "03 July 2026",
          amount: "€ 45",
        },
      ],
      footnote: "Sample data for illustration",
      vehicleNumber: "01 / 01",
    },
    benefits: {
      eyebrow: "LESS CHAOS. MORE CONTROL.",
      title: "Built for",
      accent: "your everyday life.",
      items: [
        {
          number: "01",
          title: "Everything organized",
          description:
            "Keep important details about your vehicles in one personal space.",
        },
        {
          number: "02",
          title: "Understand your spending",
          description:
            "Get a clearer view of fuel, maintenance, and other vehicle costs.",
        },
        {
          number: "03",
          title: "Keep the important details",
          description:
            "Review service history and key events whenever you need them.",
        },
      ],
    },
    services: {
      eyebrow: "02 / AUTOMOTIVE SERVICES",
      title: "The right service.",
      accent: "Easier to find.",
      description:
        "GARALANE will bring together automotive services so you can discover what you need in one place.",
      items: [
        {
          number: "01",
          name: "Auto repair shops",
          detail: "Repairs and maintenance",
        },
        { number: "02", name: "Car washes", detail: "Cleaning and care" },
        {
          number: "03",
          name: "Detailing",
          detail: "Professional vehicle care",
        },
        {
          number: "04",
          name: "Parts and accessories",
          detail: "Everything you need",
        },
      ],
      note: "The services directory is under development.",
    },
    closing: {
      eyebrow: "GARALANE",
      title: "Your car.",
      accent: "Your way.",
      action: "Back to top",
    },
    footer: {
      tagline: "Your car. Your way.",
      copyright: "© 2026 GARALANE",
      note: "Thoughtfully built, down to the details.",
    },
  },
};

export type HomeText = (typeof content)["bg"] | (typeof content)["en"];

export function getHomeText(locale: Locale): HomeText {
  return content[locale];
}
