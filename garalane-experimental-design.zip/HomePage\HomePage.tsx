import type { Locale } from "@/i18n/config";

import HomeHeader from "@/components/HomeHeader/HomeHeader";
import HomeHero from "@/components/HomeHero/HomeHero";
import GaragePreview from "@/components/GaragePreview/GaragePreview";
import HomeSections from "@/components/HomeSections/HomeSections";
import HomeFooter from "@/components/HomeFooter/HomeFooter";

import { getHomeText } from "./content";
import styles from "./HomePage.module.css";

type Props = {
  locale: Locale;
};

export default function HomePage({ locale }: Props) {
  const text = getHomeText(locale);

  return (
    <div className={styles.page} id="top">
      <HomeHeader locale={locale} text={text.nav} />

      <main>
        <HomeHero text={text.hero} />
        <HomeSections.Intro text={text.intro} />
        <GaragePreview text={text.garage} />
        <HomeSections.Benefits text={text.benefits} />
        <HomeSections.Services text={text.services} />
        <HomeSections.Closing text={text.closing} />
      </main>

      <HomeFooter text={text.footer} />
    </div>
  );
}
