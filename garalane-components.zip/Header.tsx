import Brand from "@/components/Brand/Brand";
import ArrowIcon from "@/components/ArrowIcon/ArrowIcon";
import LanguageSwitcher from "@/components/LanguageSwitcher/LanguageSwitcher";
import type { Locale } from "@/i18n/config";
import type { Dictionary } from "@/i18n/dictionaries";

type HeaderProps = {
  locale: Locale;
  dictionary: Dictionary;
};

export default function Header({ locale, dictionary }: HeaderProps) {
  const t = dictionary.nav;
  const home = `/${locale}`;

  return (
    <header className="site-header">
      <div className="container nav-inner">
        <Brand locale={locale} />

        <nav aria-label={t.about} className="nav-links">
          <a href={`${home}#garage`}>{t.garage}</a>
          <a href={`${home}#services`}>{t.services}</a>
          <a href={`${home}#vision`}>{t.about}</a>
        </nav>

        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "16px",
            flexShrink: 0,
          }}
        >
          <LanguageSwitcher locale={locale} label={t.language} />

          <a href={`${home}#garage`} className="nav-cta">
            {t.explore}
            <ArrowIcon diagonal />
          </a>
        </div>
      </div>
    </header>
  );
}
