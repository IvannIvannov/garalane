import Brand from "@/components/Brand/Brand";
import type { Locale } from "@/i18n/config";
import type { Dictionary } from "@/i18n/dictionaries";

type FooterProps = {
  locale: Locale;
  dictionary: Dictionary;
};

export default function Footer({ locale, dictionary }: FooterProps) {
  return (
    <footer className="site-footer">
      <div className="container footer-layout">
        <Brand locale={locale} />
        <span>{dictionary.footer.development}</span>
        <span>© 2026 GARALANE</span>
      </div>
    </footer>
  );
}
