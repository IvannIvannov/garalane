import { notFound } from "next/navigation";

import Header from "@/components/Header/Header";
import Footer from "@/components/Footer/Footer";
import ArrowIcon from "@/components/ArrowIcon/ArrowIcon";
import GarageShowcase from "@/components/GarageShowcase/GarageShowcase";

import { isLocale, type Locale } from "@/i18n/config";
import { getDictionary, type Dictionary } from "@/i18n/dictionaries";

type SectionProps = {
  locale: Locale;
  dictionary: Dictionary;
};

type DictionarySectionProps = {
  dictionary: Dictionary;
};

function HeroSection({ dictionary }: DictionarySectionProps) {
  const t = dictionary.hero;

  return (
    <section className="hero">
      <div className="container hero-inner">
        <div className="hero-content">
          <div className="hero-heading">
            <p className="hero-overline">{t.eyebrow}</p>

            <h1>
              {t.title}
              <br />
              <em>{t.titleAccent}</em>
            </h1>

            <p className="hero-subtitle">{t.description}</p>

            <div className="hero-actions">
              <a href="#garage" className="hero-button">
                {t.primary}
                <ArrowIcon />
              </a>

              <a href="#services" className="hero-text-link">
                {t.secondary}
                <ArrowIcon diagonal />
              </a>
            </div>

            <p className="hero-development">{t.development}</p>
          </div>

          <div className="hero-capabilities">
            <a href="#garage" className="hero-capability">
              <div className="capability-top">
                <span>01</span>
                <ArrowIcon diagonal />
              </div>

              <div>
                <h2>{t.garageTitle}</h2>
                <p>{t.garageDescription}</p>
              </div>
            </a>

            <a href="#services" className="hero-capability">
              <div className="capability-top">
                <span>02</span>
                <ArrowIcon diagonal />
              </div>

              <div>
                <h2>{t.servicesTitle}</h2>
                <p>{t.servicesDescription}</p>
              </div>
            </a>
          </div>
        </div>

        <div className="hero-bottom">
          <span>GARALANE — YOUR CAR. YOUR WAY.</span>

          <a href="#vision">
            {t.learnMore}
            <span aria-hidden="true">↓</span>
          </a>
        </div>
      </div>
    </section>
  );
}

function VisionSection({ dictionary }: DictionarySectionProps) {
  const t = dictionary.vision;

  return (
    <section id="vision" className="statement-section">
      <div className="container statement-layout">
        <p className="section-overline">{t.eyebrow}</p>

        <h2>
          {t.title}
          <span> {t.accent}</span>
        </h2>

        <p className="statement-copy">{t.description}</p>
      </div>
    </section>
  );
}

function GarageSection({ locale, dictionary }: SectionProps) {
  const t = dictionary.garage;

  return (
    <section id="garage" className="garage-section">
      <div className="container">
        <div className="section-heading">
          <div>
            <p className="section-overline">{t.eyebrow}</p>
            <h2>{t.title}</h2>
          </div>

          <p>{t.description}</p>
        </div>

        <GarageShowcase locale={locale} dictionary={dictionary} />

        <div className="garage-caption">
          <span>GARALANE GARAGE</span>
          <span>{t.preview}</span>
        </div>
      </div>
    </section>
  );
}

function BenefitsSection({ dictionary }: DictionarySectionProps) {
  const t = dictionary.benefits;

  return (
    <section className="benefits-section">
      <div className="container benefits-layout">
        <div>
          <p className="section-overline">{t.eyebrow}</p>

          <h2>
            {t.title}
            <br />
            {t.accent}
          </h2>
        </div>

        <div className="benefit-list">
          {t.items.map((item, index) => (
            <div key={item.title}>
              <span>{String(index + 1).padStart(2, "0")}</span>

              <div>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ServicesSection({ dictionary }: DictionarySectionProps) {
  const t = dictionary.services;

  return (
    <section id="services" className="services-section">
      <div className="container services-layout">
        <div className="services-intro">
          <p className="section-overline">{t.eyebrow}</p>

          <h2>
            {t.title}
            <br />
            <em>{t.accent}</em>
          </h2>

          <p>{t.description}</p>
        </div>

        <div className="service-list">
          {t.items.map((service, index) => (
            <div key={service.title} className="service-row">
              <span>{String(index + 1).padStart(2, "0")}</span>

              <div>
                <h3>{service.title}</h3>
                <p>{service.description}</p>
              </div>

              <ArrowIcon diagonal />
            </div>
          ))}

          <p className="service-disclaimer">{t.disclaimer}</p>
        </div>
      </div>
    </section>
  );
}

function ClosingSection({ dictionary }: DictionarySectionProps) {
  const t = dictionary.closing;

  return (
    <section className="end-section">
      <div className="container end-layout">
        <p>{t.eyebrow}</p>
        <h2>{t.title}</h2>

        <a href="#garage">
          {t.action}
          <ArrowIcon />
        </a>
      </div>
    </section>
  );
}

export default async function HomePage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;

  if (!isLocale(locale)) {
    notFound();
  }

  const dictionary = getDictionary(locale);

  return (
    <div className="site">
      <Header locale={locale} dictionary={dictionary} />

      <main>
        <HeroSection dictionary={dictionary} />
        <VisionSection dictionary={dictionary} />
        <GarageSection locale={locale} dictionary={dictionary} />
        <BenefitsSection dictionary={dictionary} />
        <ServicesSection dictionary={dictionary} />
        <ClosingSection dictionary={dictionary} />
      </main>

      <Footer locale={locale} dictionary={dictionary} />
    </div>
  );
}
