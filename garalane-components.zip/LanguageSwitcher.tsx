"use client";

import { useState, useTransition } from "react";
import { usePathname, useRouter } from "next/navigation";

import { locales, type Locale } from "@/i18n/config";

import { setLocalePreference } from "@/i18n/actions";

import styles from "./LanguageSwitcher.module.css";

type LanguageSwitcherProps = {
  locale: Locale;
  label: string;
};

export default function LanguageSwitcher({
  locale,
  label,
}: LanguageSwitcherProps) {
  const router = useRouter();
  const pathname = usePathname();

  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState("");

  function getLocalizedPath(targetLocale: Locale): string {
    const segments = pathname.split("/");

    if (locales.some((availableLocale) => availableLocale === segments[1])) {
      segments[1] = targetLocale;
    } else {
      segments.splice(1, 0, targetLocale);
    }

    return segments.join("/") || `/${targetLocale}`;
  }

  function changeLanguage(targetLocale: Locale) {
    if (targetLocale === locale || isPending) {
      return;
    }

    setError("");

    startTransition(async () => {
      try {
        await setLocalePreference(targetLocale);

        const path = getLocalizedPath(targetLocale);
        const search = window.location.search;
        const hash = window.location.hash;

        router.push(`${path}${search}${hash}`);
      } catch {
        setError(
          locale === "bg"
            ? "Неуспешна смяна на езика. Опитай отново."
            : "Could not change language. Please try again.",
        );
      }
    });
  }

  return (
    <div className={styles.container}>
      <div className={styles.switcher} role="group" aria-label={label}>
        {locales.map((targetLocale) => (
          <button
            key={targetLocale}
            type="button"
            lang={targetLocale}
            disabled={isPending}
            aria-pressed={targetLocale === locale}
            className={targetLocale === locale ? styles.active : ""}
            onClick={() => changeLanguage(targetLocale)}
          >
            {targetLocale.toUpperCase()}
          </button>
        ))}
      </div>

      {error && (
        <span className={styles.error} role="alert">
          {error}
        </span>
      )}
    </div>
  );
}
